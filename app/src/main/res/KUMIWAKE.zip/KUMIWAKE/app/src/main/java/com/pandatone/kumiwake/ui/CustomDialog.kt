package com.pandatone.kumiwake.ui

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.pandatone.kumiwake.R
import com.pandatone.kumiwake.setting.DBBackup
import com.pandatone.kumiwake.setting.RefreshData
import java.io.File

/**
 * Created by atsushi_2 on 2016/11/11.
 */

class CustomDialog : DialogFragment() {
    private var mTitle = ""
    private var mMessage: CharSequence = ""

    //onClickリスナ
    private val mOnClickListener = View.OnClickListener { dismiss() }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = activity?.let { Dialog(it) }
        // タイトル非表示
        dialog?.window!!.requestFeature(Window.FEATURE_NO_TITLE)
        // フルスクリーン
        dialog.window!!.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
        dialog.setContentView(R.layout.custom_dialog_layout)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        // タイトル設定
        (dialog.findViewById<View>(R.id.dialog_title) as TextView).text = mTitle
        // メッセージ設定
        (dialog.findViewById<View>(R.id.dialog_message) as TextView).text = mMessage
        // OK ボタンのリスナ
        if (mPositiveBtnListener == null) {
            dialog.findViewById<View>(R.id.negative_button).visibility = View.GONE
            dialog.findViewById<View>(R.id.positive_button).setOnClickListener(mOnClickListener)
        } else {
            dialog.findViewById<View>(R.id.positive_button).setOnClickListener(mPositiveBtnListener)
        }

        // いいえボタンのリスナ
        dialog.findViewById<View>(R.id.negative_button).setOnClickListener(mOnClickListener)
        return dialog
    }

    //タイトル
    fun setTitle(title: String) {
        mTitle = title
        mPositiveBtnListener = null
    }

    //メッセージ設定
    fun setMessage(msg: CharSequence) {
        mMessage = msg
    }

    fun setOnPositiveClickListener(code: Int) {
        mPositiveBtnListener = View.OnClickListener {
            when (code) {
                1 -> activity?.let { it1 -> DBBackup.dbBackup(it1) }
                2 -> activity?.let { it1 -> DBBackup.dbImport(it1) }
                3 -> {
                    val mbFile = File(Environment.getExternalStorageDirectory().path + "/KUMIWAKE_Backup/mb.db")
                    val gpFile = File(Environment.getExternalStorageDirectory().path + "/KUMIWAKE_Backup/gp.db")
                    val dir = File(Environment.getExternalStorageDirectory().path + "/KUMIWAKE_Backup")

                    if (!dir.exists()) {
                        Toast.makeText(activity, getString(R.string.not_exist_file), Toast.LENGTH_SHORT).show()
                        dismiss()
                        return@OnClickListener
                    }
                    mbFile.delete()
                    gpFile.delete()
                    dir.delete()
                    Toast.makeText(activity, getString(R.string.deleted_backup_file), Toast.LENGTH_SHORT).show()
                }
                4 -> activity?.let { it1 -> RefreshData.refresh(it1) }
            }
            dismiss()
        }
    }

    companion object {
        var mPositiveBtnListener: View.OnClickListener? = null
    }
}
