# KUMIWAKE

Created By PANDATONE.

Store (GooglePlay):</br>
https://play.google.com/store/apps/details?id=com.pandatone.kumiwake

Privacy Policy:
https://gist.githubusercontent.com/KawabeAtsushi/39f3ea332b05a6b053b263784a77cd51/raw/7666e22b85561c34a95863f9482ed900482d2c8d/privacy%2520policy

## Easy grouping in favorite conditions!
## You can also determined seats allocation!

Determine group every time when the circle with sesh, allot the seats are uncomfortable...

I want to grouping so as to age is equalized...

This is the app "KUMIWAKE" to help in such case!

("KUMIWAKE" means "Grouping" in Japanese)

### ◆ Grouping

If you use the "KUMIWAKE", equally gender,age, job title, etc., it is possible to the grouping automatically.

By pre-registered members, can perform the grouping by personal name, it is very convenient.

Also,you will find it easier to do "KUMIWAKE" the usual group that you registered in the "group" members.

### ◆ seat allocation

You can decide the seat to each group at random.

You can decide the seat as "men and women alternately" also, can also be carried out it from the group that you created in the "grouping"!

You can seats decided from four types according to the table type of the place.


Please use at the time of group activities by all means! !

<Opinions and requests>
E-mail:ganbalism@gmail.com

*This app support English and Japanese.*

## バージョン履歴
■ver.1.0.0（major update）<br>
・KUMIWAKEリリース！

■ver.2.0.0（major update）<br>
・結果シェア機能の実装

■ver.2.1.0<br>
・KUMIWAKEのメンバー選択画面でメンバーの追加が可能に。

■ver.2.2.0<br>
・メンバーの追加が連続で行えるようになりました。

## ToDo
### MVVMアーキテクチャ対応
[師匠の記事](https://qiita.com/rmakiyama/items/779cf6407f70b40e4ee7)

[DataBindingで実現するMVVM Architecture](https://speakerdeck.com/star_zero/databindingteshi-xian-surumvvm-architecture?slide=27)
### スコープ関数 & inline
[Kotlin スコープ関数 用途まとめ](https://qiita.com/ngsw_taro/items/d29e3080d9fc8a38691e)

[Kotlinのスコープ関数を使い分けたい](http://nyanyoni.hateblo.jp/entry/2017/08/19/152200)
### Retrofit（別アプリ？）
[Retrofit2使い方](https://qiita.com/SYABU555/items/3b280a8e81d2cc897383)
### 拡張関数
### できる限りConstraintlayoutに置き換える
[XMLで始めるConstraintLayout](https://qiita.com/nakker1218/items/0faa8c1ab504cc4cedea)

[ConstraintLayout レイアウト逆引きまとめ](https://qiita.com/tktktks10/items/62d85dabac4bdb8c1f94)
